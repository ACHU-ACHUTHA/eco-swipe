import React, { useState, useEffect, useRef } from 'react';
import { 
  Home, 
  List, 
  Gamepad2, 
  MessageSquare, 
  User, 
  Search, 
  Camera, 
  Upload, 
  ArrowRight, 
  Check, 
  X,
  XCircle,
  Bell, 
  MapPin, 
  LogOut, 
  ShieldCheck, 
  ChevronRight,
  Sun,
  Moon,
  PhoneCall,
  BarChart3,
  MessageCircle,
  Send,
  Leaf,
  Trash2,
  Zap,
  Search as SearchIcon,
  PlusCircle,
  Award,
  Compass,
  CloudUpload,
  Sparkles,
  Handshake,
  Telescope,
  Truck,
  RefreshCw,
  Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  signOut,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword
} from 'firebase/auth';
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  onSnapshot, 
  query, 
  where, 
  orderBy, 
  addDoc,
  updateDoc,
  deleteDoc,
  Timestamp,
  getDocFromServer
} from 'firebase/firestore';
import confetti from 'canvas-confetti';
import { auth, db } from './firebase';
import { cn } from './lib/utils';
import { 
  Role, 
  Screen, 
  UserProfile, 
  Listing, 
  Request, 
  Notification, 
  AIResult,
  ChatMessage,
  AnalyticsData
} from './types';
import { classifyWaste, getRecyclingAdvice } from './services/geminiService';

// --- Constants ---

const MARKET_PRICES: Record<string, number> = {
  'Plastic': 45,
  'Metal': 120,
  'Paper': 15,
  'Glass': 25,
  'Electronic': 250,
  'Organic': 10,
  'Textile': 35,
  'Rubber': 40,
  'Scrap': 30,
  'Default': 20
};

// --- Components ---

const ErrorBoundary = ({ children }: { children: React.ReactNode }) => {
  const [hasError, setHasError] = useState(false);
  const [errorInfo, setErrorInfo] = useState<string | null>(null);

  useEffect(() => {
    const handleError = (error: ErrorEvent) => {
      setHasError(true);
      setErrorInfo(error.message);
    };
    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, []);

  if (hasError) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 text-center bg-red-50">
        <h1 className="text-2xl font-bold text-red-600 mb-2">Something went wrong</h1>
        <p className="text-gray-600 mb-4">{errorInfo}</p>
        <button 
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-red-600 text-white rounded-lg"
        >
          Reload App
        </button>
      </div>
    );
  }

  return <>{children}</>;
};

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [screen, setScreen] = useState<Screen>('home');
  const [role, setRole] = useState<Role>('buyer');
  const [listings, setListings] = useState<Listing[]>([]);
  const [requests, setRequests] = useState<Request[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [isLoginView, setIsLoginView] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Seller State
  const [uploading, setUploading] = useState(false);
  const [aiResult, setAiResult] = useState<AIResult | null>(null);
  const [sellerLocation, setSellerLocation] = useState('');
  const [sellerWeight, setSellerWeight] = useState<number>(10);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  // MatchMaker State
  const [matchIndex, setMatchIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  // Chatbot State
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);

  // Analytics State
  const [isAnalyticsOpen, setIsAnalyticsOpen] = useState(false);
  const [isBuyModalOpen, setIsBuyModalOpen] = useState(false);
  const [selectedListing, setSelectedListing] = useState<Listing | null>(null);
  const [buyWeight, setBuyWeight] = useState<number>(0);
  const [dateFilter, setDateFilter] = useState<'week' | 'month' | 'all' | 'custom'>('all');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');

  const getFilteredData = () => {
    const now = new Date();
    let filterStartDate = new Date(0);
    let filterEndDate = new Date();

    if (dateFilter === 'week') {
      filterStartDate = new Date(now.setDate(now.getDate() - 7));
    } else if (dateFilter === 'month') {
      filterStartDate = new Date(now.setMonth(now.getMonth() - 1));
    } else if (dateFilter === 'custom') {
      if (customStartDate) filterStartDate = new Date(customStartDate);
      if (customEndDate) filterEndDate = new Date(customEndDate);
    }

    const filteredRequests = requests.filter(r => {
      const d = new Date(r.createdAt);
      return d >= filterStartDate && d <= filterEndDate && r.status === 'accepted';
    });

    const filteredListings = listings.filter(l => {
      const d = new Date(l.createdAt);
      return d >= filterStartDate && d <= filterEndDate && l.sellerId === user?.uid;
    });

    if (role === 'seller') {
      const totalWeight = filteredListings.reduce((acc, l) => acc + l.weight, 0);
      const totalEarned = filteredRequests.reduce((acc, r) => acc + (r.price || 0) * (r.weight || 0), 0);
      return { totalWeight, totalValue: totalEarned, profit: 0, items: filteredRequests };
    } else {
      const totalWeight = filteredRequests.reduce((acc, r) => acc + (r.weight || 0), 0);
      const totalSpent = filteredRequests.reduce((acc, r) => acc + (r.price || 0) * (r.weight || 0), 0);
      const totalProfit = filteredRequests.reduce((acc, r) => {
        const marketPrice = MARKET_PRICES[r.wasteName] || MARKET_PRICES['Default'];
        return acc + (marketPrice - (r.price || 0)) * (r.weight || 0);
      }, 0);
      return { totalWeight, totalValue: totalSpent, profit: totalProfit, items: filteredRequests };
    }
  };

  const analytics = getFilteredData();

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
        if (userDoc.exists()) {
          const userData = userDoc.data() as UserProfile;
          setUser(userData);
          setRole(userData.role);
          setIsDarkMode(userData.darkMode || false);
        } else {
          // New user from Google Auth
          const newUser: UserProfile = {
            uid: firebaseUser.uid,
            name: firebaseUser.displayName || 'User',
            email: firebaseUser.email || '',
            role: 'buyer',
            trustScore: 85,
            earnings: 0,
            darkMode: false
          };
          await setDoc(doc(db, 'users', firebaseUser.uid), newUser);
          setUser(newUser);
          setRole('buyer');
          setIsDarkMode(false);
        }
      } else {
        setUser(null);
      }
      setLoading(false);
      setIsAuthReady(true);
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!isAuthReady || !user) return;

    // Test connection
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
        console.log("Firebase connection successful.");
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Firebase connection failed: The client is offline. Please check your Firebase configuration and ensure the database is provisioned.");
        } else {
          console.error("Firebase connection error:", error);
        }
      }
    };
    testConnection();

    // Listeners
    const qListings = query(collection(db, 'listings'), orderBy('createdAt', 'desc'));
    const unsubListings = onSnapshot(qListings, (snapshot) => {
      setListings(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Listing)));
    }, (error) => handleFirestoreError(error, 'list', 'listings'));

    const qRequests = query(collection(db, 'requests'), where(role === 'seller' ? 'sellerId' : 'buyerId', '==', user.uid));
    const unsubRequests = onSnapshot(qRequests, (snapshot) => {
      setRequests(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Request)));
    }, (error) => handleFirestoreError(error, 'list', 'requests'));

    const qNotifications = query(collection(db, 'notifications'), where('userId', '==', user.uid));
    const unsubNotifications = onSnapshot(qNotifications, (snapshot) => {
      setNotifications(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Notification)));
    }, (error) => handleFirestoreError(error, 'list', 'notifications'));

    return () => {
      unsubListings();
      unsubRequests();
      unsubNotifications();
    };
  }, [isAuthReady, user, role]);

  const handleFirestoreError = (error: any, operationType: string, path: string) => {
    const errInfo = {
      error: error.message,
      operationType,
      path,
      authInfo: {
        userId: auth.currentUser?.uid,
        email: auth.currentUser?.email
      }
    };
    console.error('Firestore Error: ', JSON.stringify(errInfo));
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (isLoginView) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        const res = await createUserWithEmailAndPassword(auth, email, password);
        const newUser: UserProfile = {
          uid: res.user.uid,
          name: name,
          email: email,
          role: 'buyer',
          trustScore: 85,
          earnings: 0,
          totalWeight: 0,
          totalProfit: 0,
          darkMode: false
        };
        await setDoc(doc(db, 'users', res.user.uid), newUser);
      }
    } catch (error: any) {
      alert(error.message);
    }
  };

  const handleGoogleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      alert(error.message);
    }
  };

  const handleSendMessage = async () => {
    if (!chatInput.trim()) return;
    const userMsg: ChatMessage = { role: 'user', text: chatInput };
    setChatMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setIsChatLoading(true);
    try {
      const advice = await getRecyclingAdvice(chatInput, chatMessages);
      setChatMessages(prev => [...prev, { role: 'model', text: advice }]);
    } catch (error) {
      console.error(error);
    } finally {
      setIsChatLoading(false);
    }
  };

  const toggleRole = async () => {
    const newRole = role === 'buyer' ? 'seller' : 'buyer';
    setRole(newRole);
    if (user) {
      await updateDoc(doc(db, 'users', user.uid), { role: newRole });
    }
    setScreen('home');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      setUploadedImage(base64);
      setUploading(true);
      try {
        const result = await classifyWaste(base64);
        setAiResult(result);
      } catch (error) {
        console.error(error);
      } finally {
        setUploading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const toggleDarkMode = async () => {
    if (!user) return;
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    try {
      await updateDoc(doc(db, 'users', user.uid), { darkMode: newMode });
    } catch (error) {
      console.error("Error updating dark mode:", error);
    }
  };

  const createListing = async () => {
    if (!aiResult || !user) return;
    try {
      await addDoc(collection(db, 'listings'), {
        sellerId: user.uid,
        sellerName: user.name,
        materialType: aiResult.materialType,
        weight: sellerWeight,
        price: aiResult.suggestedPrice,
        location: sellerLocation,
        quality: aiResult.quality,
        suggestedIndustries: aiResult.suggestedIndustries,
        imageUrl: uploadedImage,
        sellerTrustScore: user.trustScore || 85,
        createdAt: new Date().toISOString()
      });
      setAiResult(null);
      setUploadedImage(null);
      setSellerLocation('');
      setSellerWeight(10);
      alert('Listing created successfully!');
    } catch (error) {
      console.error(error);
    }
  };

  const sendRequest = async (listing: Listing, requestedWeight: number) => {
    if (!user) return;
    try {
      await addDoc(collection(db, 'requests'), {
        listingId: listing.id,
        buyerId: user.uid,
        buyerName: user.name,
        sellerId: listing.sellerId,
        status: 'pending',
        wasteName: listing.materialType,
        price: listing.price,
        weight: requestedWeight,
        createdAt: new Date().toISOString()
      });
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
      setIsBuyModalOpen(false);
    } catch (error) {
      console.error(error);
    }
  };

  const handleRequestAction = async (request: Request, status: 'accepted' | 'rejected') => {
    try {
      await updateDoc(doc(db, 'requests', request.id), { status });
      if (status === 'accepted') {
        confetti();
        
        // Update seller earnings
        const earningsIncrease = (request.price || 0) * (request.weight || 0);
        const sellerDoc = await getDoc(doc(db, 'users', request.sellerId));
        if (sellerDoc.exists()) {
          const currentEarnings = sellerDoc.data().earnings || 0;
          await updateDoc(doc(db, 'users', request.sellerId), { 
            earnings: currentEarnings + earningsIncrease 
          });
        }

        // Update buyer profile (total weight and profit)
        const marketPrice = MARKET_PRICES[request.wasteName] || MARKET_PRICES['Default'];
        const profit = (marketPrice - (request.price || 0)) * (request.weight || 0);
        const buyerDoc = await getDoc(doc(db, 'users', request.buyerId));
        if (buyerDoc.exists()) {
          const buyerData = buyerDoc.data();
          const currentWeight = buyerData.totalWeight || 0;
          const currentProfit = buyerData.totalProfit || 0;
          await updateDoc(doc(db, 'users', request.buyerId), {
            totalWeight: currentWeight + (request.weight || 0),
            totalProfit: currentProfit + profit
          });
        }

        await addDoc(collection(db, 'notifications'), {
          userId: request.buyerId,
          message: `Your request for ${request.wasteName} has been accepted 🎉`,
          type: 'success',
          read: false,
          createdAt: new Date().toISOString()
        });
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleDeleteListing = async (listingId: string) => {
    try {
      await deleteDoc(doc(db, 'listings', listingId));
      setNotifications(prev => [{
        id: Date.now().toString(),
        userId: user?.uid || '',
        message: 'Listing deleted successfully',
        type: 'success',
        read: false,
        createdAt: new Date().toISOString()
      }, ...prev]);
    } catch (error) {
      console.error(error);
    }
  };

  if (loading) return <div className="flex items-center justify-center min-h-screen">Loading...</div>;

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-cream">
        <div className="w-full max-w-md bg-white rounded-3xl p-8 shadow-xl">
          <div className="text-center mb-8">
            <Logo size="lg" className="justify-center mb-4" />
            <p className="text-gray-500">AI-Powered Industrial Waste Marketplace</p>
          </div>
          
          <form onSubmit={handleLogin} className="space-y-4">
            {!isLoginView && (
              <input 
                type="text" 
                placeholder="Full Name" 
                className="w-full p-4 rounded-xl border border-gray-200 focus:ring-2 focus:ring-buyer-primary outline-none"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            )}
            <input 
              type="email" 
              placeholder="Email" 
              className="w-full p-4 rounded-xl border border-gray-200 focus:ring-2 focus:ring-buyer-primary outline-none"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <input 
              type="password" 
              placeholder="Password" 
              className="w-full p-4 rounded-xl border border-gray-200 focus:ring-2 focus:ring-buyer-primary outline-none"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button className="w-full py-4 bg-buyer-primary text-white rounded-xl font-bold hover:bg-opacity-90 transition-all">
              {isLoginView ? 'Sign In' : 'Sign Up'}
            </button>
          </form>

          <div className="mt-6 flex items-center gap-4 text-gray-400">
            <div className="flex-1 h-px bg-gray-200"></div>
            <span>or</span>
            <div className="flex-1 h-px bg-gray-200"></div>
          </div>

          <button 
            onClick={handleGoogleLogin}
            className="w-full mt-6 py-4 border border-gray-200 rounded-xl flex items-center justify-center gap-3 hover:bg-gray-50 transition-all"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/layout/google.svg" className="w-6 h-6" alt="Google" />
            <span className="font-medium">Continue with Google</span>
          </button>

          <p className="mt-8 text-center text-gray-500">
            {isLoginView ? "Don't have an account?" : "Already have an account?"}{' '}
            <button 
              onClick={() => setIsLoginView(!isLoginView)}
              className="text-buyer-primary font-bold"
            >
              {isLoginView ? 'Sign Up' : 'Sign In'}
            </button>
          </p>
        </div>
      </div>
    );
  }

  const themeClass = role === 'buyer' ? 'buyer-theme' : 'seller-theme';
  const primaryColor = role === 'buyer' ? 'text-buyer-primary' : 'text-seller-primary';
  const bgColor = role === 'buyer' ? 'bg-buyer-primary' : 'bg-seller-primary';

  return (
    <ErrorBoundary>
      <div className={cn("min-h-screen flex flex-col md:flex-row", themeClass)}>
        
        {/* Sidebar - Desktop */}
        <aside className="hidden md:flex flex-col w-64 bg-white border-r border-gray-100 p-6 fixed h-full">
          <div className="mb-10">
            <Logo />
          </div>
          
          <nav className="flex-1 space-y-2">
            {[
              { id: 'home', icon: Home, label: 'Home' },
              { id: role === 'buyer' ? 'buyer' : 'seller', icon: List, label: role === 'buyer' ? 'Listings' : 'My Waste' },
              { id: 'messages', icon: MessageSquare, label: 'Messages' },
              { id: 'profile', icon: User, label: 'Profile' },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setScreen(item.id as Screen)}
                className={cn(
                  "w-full flex items-center gap-4 p-4 rounded-2xl transition-all",
                  screen === item.id ? cn(bgColor, "text-white shadow-lg") : "text-gray-500 hover:bg-gray-50"
                )}
              >
                <item.icon size={20} />
                <span className="font-medium">{item.label}</span>
              </button>
            ))}
            {role === 'seller' && (
              <button
                onClick={() => setScreen('seller')}
                className={cn(
                  "w-full flex items-center gap-4 p-4 rounded-2xl transition-all",
                  screen === 'seller' ? cn(bgColor, "text-white shadow-lg") : "text-gray-500 hover:bg-gray-50"
                )}
              >
                <List size={20} />
                <span className="font-medium">My Listings</span>
              </button>
            )}
          </nav>

          <button 
            onClick={() => signOut(auth)}
            className="flex items-center gap-4 p-4 text-red-500 hover:bg-red-50 rounded-2xl transition-all"
          >
            <LogOut size={20} />
            <span className="font-medium">Logout</span>
          </button>
        </aside>

        {/* Main Content */}
        <main className="flex-1 md:ml-64 pb-24 md:pb-0">
          
          {/* Header */}
          <header className="sticky top-0 z-10 bg-cream/80 backdrop-blur-md p-4 md:p-6 flex items-center justify-between">
            <div className="md:hidden">
              <Logo size="sm" />
            </div>
            <div className="hidden md:block">
              <h2 className="text-xl font-semibold text-gray-800 capitalize">{screen}</h2>
            </div>
            
            <div className="flex items-center gap-3">
              <button 
                onClick={toggleRole}
                className={cn(
                  "px-4 py-2 rounded-full text-white font-bold text-sm shadow-md transition-all",
                  role === 'buyer' ? "bg-seller-primary" : "bg-buyer-primary"
                )}
              >
                {role === 'buyer' ? 'SELL' : 'BUY'}
              </button>
            </div>
          </header>

          <div className="p-4 md:p-8 max-w-5xl mx-auto">
            <AnimatePresence mode="wait">
              {screen === 'home' && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-8"
                >
                  {/* Search */}
                  <div className="relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                    <input 
                      type="text" 
                      placeholder="Search for waste categories..." 
                      className="w-full p-4 pl-12 bg-white rounded-2xl shadow-sm outline-none focus:ring-2 focus:ring-primary"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>

                  {/* AI Insight */}
                  <div className={cn("p-6 rounded-3xl text-white shadow-xl relative overflow-hidden", bgColor)}>
                    <div className="relative z-10">
                      <h3 className="text-lg font-medium opacity-90">AI Insight</h3>
                      <p className="text-2xl font-bold mt-1">You can earn ₹12,000/month from scrap</p>
                      <button 
                        onClick={() => setIsAnalyticsOpen(true)}
                        className="mt-4 px-6 py-2 bg-white/20 backdrop-blur-md rounded-xl font-medium hover:bg-white/30 transition-all"
                      >
                        View Analytics
                      </button>
                    </div>
                    <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
                  </div>

                  {/* Quick Actions */}
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { 
                        id: 'upload', 
                        icon: role === 'seller' ? CloudUpload : SearchIcon, 
                        label: role === 'seller' ? 'Upload' : 'Find', 
                        color: role === 'seller' ? 'bg-blue-500 text-blue-600' : 'bg-indigo-500 text-indigo-600',
                        action: () => setScreen(role === 'seller' ? 'seller' : 'buyer') 
                      },
                      { 
                        id: 'trust', 
                        icon: Handshake, 
                        label: 'Trust', 
                        color: 'bg-amber-500 text-amber-600',
                        action: () => {} 
                      },
                      { 
                        id: 'match', 
                        icon: Zap, 
                        label: 'Match', 
                        color: 'bg-purple-500 text-purple-600',
                        action: () => setScreen('matchmaker') 
                      },
                    ].map((item, i) => (
                      (role === 'buyer' || (role === 'seller' && item.id !== 'match')) && (
                        <button 
                          key={i}
                          onClick={item.action}
                          className="flex flex-col items-center gap-3 p-5 bg-white rounded-[2.5rem] shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all group border border-gray-50"
                        >
                          <div className={cn(
                            "p-4 rounded-2xl bg-opacity-10 group-hover:scale-110 transition-transform shadow-inner", 
                            item.color
                          )}>
                            <item.icon size={30} strokeWidth={2.5} />
                          </div>
                          <span className="text-xs font-black text-gray-800 uppercase tracking-widest">{item.label}</span>
                        </button>
                      )
                    ))}
                  </div>

                  {/* Preview Listings */}
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-bold">Recent Listings</h3>
                      <button onClick={() => setScreen(role === 'buyer' ? 'buyer' : 'seller')} className={cn("text-sm font-bold", primaryColor)}>View All</button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {listings.slice(0, 4).map((listing) => (
                        <ListingCard key={listing.id} listing={listing} onAction={() => setScreen('buyer')} />
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {screen === 'buyer' && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-8"
                >
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold">Marketplace</h2>
                    <div className="flex gap-2">
                      <button className="px-4 py-2 bg-white rounded-xl text-sm font-bold shadow-sm">Filter</button>
                    </div>
                  </div>

                  {/* Recommended */}
                  <div>
                    <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                      <ShieldCheck className="text-yellow-500" size={20} />
                      Recommended for You
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {listings.filter(l => l.materialType.toLowerCase().includes(searchQuery.toLowerCase())).map((listing) => (
                        <ListingCard 
                          key={listing.id} 
                          listing={listing} 
                          onAction={() => {
                            setSelectedListing(listing);
                            setBuyWeight(listing.weight);
                            setIsBuyModalOpen(true);
                          }}
                          isBuyer
                        />
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {screen === 'seller' && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-8"
                >
                  <div className="bg-white p-8 rounded-3xl shadow-sm text-center border-2 border-dashed border-gray-200">
                    {!uploadedImage ? (
                      <div className="space-y-4">
                        <div className="w-20 h-20 bg-seller-primary/10 rounded-full flex items-center justify-center mx-auto text-seller-primary">
                          <Camera size={40} />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold">Upload Waste Photo</h3>
                          <p className="text-gray-500">AI will classify and estimate price</p>
                        </div>
                        <div className="flex justify-center gap-4">
                          <label className="px-6 py-3 bg-seller-primary text-white rounded-xl font-bold cursor-pointer hover:bg-opacity-90 transition-all flex items-center gap-2">
                            <Camera size={20} />
                            Take Photo
                            <input type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFileUpload} />
                          </label>
                          <label className="px-6 py-3 border border-gray-200 rounded-xl font-bold cursor-pointer hover:bg-gray-50 transition-all flex items-center gap-2">
                            <Upload size={20} />
                            Upload
                            <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
                          </label>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-6">
                        <img src={uploadedImage} className="w-full max-h-64 object-cover rounded-2xl" alt="Preview" />
                        {uploading ? (
                          <div className="flex items-center justify-center gap-2 text-seller-primary font-bold">
                            <div className="w-5 h-5 border-2 border-seller-primary border-t-transparent rounded-full animate-spin"></div>
                            AI is classifying...
                          </div>
                        ) : aiResult && (
                          <div className="text-left space-y-4 bg-gray-50 p-6 rounded-2xl">
                            <div className="flex justify-between items-center">
                              <h4 className="text-2xl font-bold text-seller-primary">{aiResult.materialType}</h4>
                              <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold">{aiResult.quality}</span>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="p-3 bg-white rounded-xl shadow-sm">
                                <span className="text-xs text-gray-500">Estimated Price</span>
                                <p className="text-lg font-bold">₹{aiResult.suggestedPrice}/kg</p>
                              </div>
                              <div className="p-3 bg-white rounded-xl shadow-sm">
                                <span className="text-xs text-gray-500">Quality</span>
                                <p className="text-lg font-bold">{aiResult.quality}</p>
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <label className="text-sm font-bold text-gray-600">Weight (kg)</label>
                                <input 
                                  type="number" 
                                  placeholder="Enter weight" 
                                  className="w-full p-4 bg-white rounded-xl outline-none focus:ring-2 focus:ring-seller-primary"
                                  value={sellerWeight}
                                  onChange={(e) => setSellerWeight(Number(e.target.value))}
                                />
                              </div>
                              <div className="space-y-2">
                                <label className="text-sm font-bold text-gray-600">Location</label>
                                <input 
                                  type="text" 
                                  placeholder="City/Region" 
                                  className="w-full p-4 bg-white rounded-xl outline-none focus:ring-2 focus:ring-seller-primary"
                                  value={sellerLocation}
                                  onChange={(e) => setSellerLocation(e.target.value)}
                                />
                              </div>
                            </div>
                            <div className="flex gap-3">
                              <button 
                                onClick={createListing}
                                className="flex-1 py-4 bg-seller-primary text-white rounded-xl font-bold shadow-lg"
                              >
                                Confirm Listing
                              </button>
                              <button 
                                onClick={() => {setUploadedImage(null); setAiResult(null);}}
                                className="px-6 py-4 border border-gray-200 rounded-xl font-bold"
                              >
                                Cancel
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* My Listings Section for Seller */}
                  <div>
                    <h3 className="text-xl font-bold mb-4">My Listings</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {listings.filter(l => l.sellerId === user.uid).length === 0 ? (
                        <p className="text-gray-500 text-center py-10 col-span-full">You haven't listed any waste yet</p>
                      ) : (
                        listings.filter(l => l.sellerId === user.uid).map((listing) => (
                          <ListingCard 
                            key={listing.id} 
                            listing={listing} 
                            onAction={() => {}}
                            onDelete={() => handleDeleteListing(listing.id)}
                            isSellerOwn
                          />
                        ))
                      )}
                    </div>
                  </div>
                </motion.div>
              )}

              {screen === 'matchmaker' && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="fixed inset-0 z-50 bg-black/90 flex flex-col items-center justify-center p-4"
                >
                  <button 
                    onClick={() => setScreen('home')}
                    className="absolute top-8 left-8 text-white flex items-center gap-2 font-bold"
                  >
                    <X size={24} /> Exit
                  </button>

                  <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold text-white mb-1">MatchMaker</h2>
                  </div>

                  <div className="relative w-full max-w-sm aspect-[3/4]">
                    {listings.length > matchIndex ? (
                      <motion.div 
                        drag="x"
                        dragConstraints={{ left: 0, right: 0 }}
                        onDragEnd={(_, info) => {
                          if (info.offset.x > 100) {
                            const listing = listings[matchIndex];
                            setSelectedListing(listing);
                            setBuyWeight(listing.weight);
                            setIsBuyModalOpen(true);
                            setMatchIndex(prev => prev + 1);
                          } else if (info.offset.x < -100) {
                            setMatchIndex(prev => prev + 1);
                          }
                        }}
                        className={cn("swipe-card w-full h-full cursor-grab active:cursor-grabbing", isFlipped && "flipped")}
                      >
                        <div className="swipe-card-inner w-full h-full relative">
                          {/* Front */}
                          <div className="swipe-card-front absolute inset-0 bg-white rounded-[2rem] overflow-hidden shadow-2xl">
                            <img src={listings[matchIndex].imageUrl} className="w-full h-1/2 object-cover" alt="Waste" />
                            <div className="p-6 space-y-4">
                              <div className="flex justify-between items-start">
                                <h3 className="text-2xl font-bold">{listings[matchIndex].materialType}</h3>
                                <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold">98% Match</span>
                              </div>
                              <div className="grid grid-cols-2 gap-4 text-sm">
                                <div className="flex items-center gap-2 text-gray-500">
                                  <ShieldCheck size={16} /> {listings[matchIndex].weight}kg
                                </div>
                                <div className="flex items-center gap-2 text-gray-500">
                                  <MapPin size={16} /> {listings[matchIndex].location}
                                </div>
                              </div>
                              <p className="text-3xl font-black text-buyer-primary">₹{listings[matchIndex].price}/kg</p>
                              <button 
                                onClick={() => setIsFlipped(true)}
                                className="w-full py-3 bg-gray-100 rounded-xl font-bold text-gray-600 flex items-center justify-center gap-2"
                              >
                                Details <ChevronRight size={18} />
                              </button>
                            </div>
                          </div>

                          {/* Back */}
                          <div className="swipe-card-back absolute inset-0 bg-buyer-primary rounded-[2rem] p-8 text-white flex flex-col justify-between shadow-2xl">
                            <div className="space-y-6">
                              <h3 className="text-2xl font-bold">AI Match Insight</h3>
                              <div className="space-y-4">
                                <p className="text-white/80">This waste is suitable for:</p>
                                <div className="space-y-2">
                                  {listings[matchIndex].suggestedIndustries.map((ind, i) => (
                                    <div key={i} className="flex items-center gap-3 bg-white/10 p-3 rounded-xl">
                                      <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center text-xs font-bold">{i+1}</div>
                                      <span className="font-medium">{ind}</span>
                                    </div>
                                  ))}
                                </div>
                                <button 
                                  onClick={() => window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(listings[matchIndex].location)}`)}
                                  className="flex items-center gap-2 text-sm font-bold text-white underline"
                                >
                                  <MapPin size={16} /> View Seller Location
                                </button>
                              </div>
                              <p className="text-sm italic text-white/70">"AI recommends this match based on industry demand"</p>
                            </div>
                            
                            <div className="flex justify-center gap-6">
                              <button 
                                onClick={() => {setIsFlipped(false); setMatchIndex(prev => prev + 1);}}
                                className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center shadow-lg glow-btn"
                              >
                                <X size={20} />
                              </button>
                              <button 
                                onClick={() => {
                                  const listing = listings[matchIndex];
                                  setSelectedListing(listing);
                                  setBuyWeight(listing.weight);
                                  setIsBuyModalOpen(true);
                                  setIsFlipped(false);
                                  setMatchIndex(prev => prev + 1);
                                }}
                                className="w-12 h-12 bg-white text-black rounded-full flex items-center justify-center shadow-lg glow-btn"
                              >
                                <Check size={20} />
                              </button>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full text-white">
                        <Gamepad2 size={64} className="mb-4 opacity-20" />
                        <p className="text-xl font-bold">No more matches today!</p>
                        <button onClick={() => setMatchIndex(0)} className="mt-4 text-buyer-secondary font-bold underline">Refresh</button>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {screen === 'messages' && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-6"
                >
                  <h2 className="text-2xl font-bold">Messages & Requests</h2>
                  
                  {role === 'seller' && (
                    <div className="space-y-4 mb-8">
                      <h3 className="text-lg font-bold flex items-center gap-2">
                        <ArrowRight className="text-seller-primary" size={20} />
                        Incoming Buyer Requests
                      </h3>
                      {requests.filter(r => r.status === 'pending').length === 0 ? (
                        <p className="text-gray-500 text-sm italic">No pending requests</p>
                      ) : (
                        requests.filter(r => r.status === 'pending').map((req) => (
                          <div key={req.id} className="bg-white p-6 rounded-3xl shadow-sm flex items-center justify-between border border-gray-50">
                            <div>
                              <h4 className="font-bold text-lg">{req.wasteName}</h4>
                              <p className="text-sm text-gray-500">From: {req.buyerName}</p>
                            </div>
                            <div className="flex gap-2">
                              <button 
                                onClick={() => handleRequestAction(req, 'accepted')}
                                className="p-3 bg-green-500 text-white rounded-full shadow-lg hover:scale-110 transition-all"
                              >
                                <Check size={20} />
                              </button>
                              <button 
                                onClick={() => handleRequestAction(req, 'rejected')}
                                className="p-3 bg-red-500 text-white rounded-full shadow-lg hover:scale-110 transition-all"
                              >
                                <X size={20} />
                              </button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}

                  <div className="space-y-4">
                    <h3 className="text-lg font-bold">Notifications</h3>
                    {notifications.length === 0 ? (
                      <p className="text-gray-500 text-center py-10">No updates yet</p>
                    ) : (
                      notifications.map((notif) => (
                        <div key={notif.id} className="bg-white p-6 rounded-3xl shadow-sm flex items-start gap-4">
                          <div className={cn("p-3 rounded-full", notif.type === 'success' ? "bg-green-100 text-green-600" : "bg-blue-100 text-blue-600")}>
                            <Bell size={20} />
                          </div>
                          <div className="flex-1">
                            <p className="font-medium text-gray-800">{notif.message}</p>
                            <span className="text-xs text-gray-400 mt-1 block">{new Date(notif.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </motion.div>
              )}

              {screen === 'profile' && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-8"
                >
                  <div className="bg-white p-8 rounded-3xl shadow-sm text-center">
                    <div className="w-24 h-24 bg-gray-100 rounded-full mx-auto mb-4 flex items-center justify-center text-3xl font-bold text-gray-400">
                      {user.name[0]}
                    </div>
                    <h2 className="text-2xl font-bold">{user.name}</h2>
                    <p className="text-gray-500">{user.email}</p>
                    <div className="grid grid-cols-2 gap-4 mt-8">
                      <div className="p-4 bg-gray-50 rounded-2xl">
                        <span className="text-xs text-gray-500 block">Trust Score</span>
                        <span className="text-xl font-bold text-green-600">{user.trustScore}%</span>
                      </div>
                      <div className="p-4 bg-gray-50 rounded-2xl">
                        <span className="text-xs text-gray-500 block">{role === 'buyer' ? 'Total Profit' : 'Earnings'}</span>
                        <span className="text-xl font-bold">₹{role === 'buyer' ? (user.totalProfit || 0) : user.earnings}</span>
                      </div>
                      {role === 'buyer' && (
                        <div className="p-4 bg-gray-50 rounded-2xl col-span-2">
                          <span className="text-xs text-gray-500 block">Total Waste Purchased</span>
                          <span className="text-xl font-bold">{user.totalWeight || 0} kg</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-bold">Account Settings</h3>
                    <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-sm overflow-hidden">
                      <button 
                        onClick={toggleDarkMode}
                        className="w-full p-6 flex items-center justify-between border-b border-gray-50 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-all"
                      >
                        <div className="flex items-center gap-4">
                          <Moon size={20} className={isDarkMode ? "text-yellow-400" : "text-gray-400"} />
                          <span className="font-medium dark:text-white">Dark Mode</span>
                        </div>
                        <div className={cn("w-12 h-6 rounded-full relative transition-all", isDarkMode ? "bg-green-500" : "bg-gray-200")}>
                          <div className={cn("absolute top-1 w-4 h-4 bg-white rounded-full transition-all", isDarkMode ? "left-7" : "left-1")}></div>
                        </div>
                      </button>
                      <button 
                        onClick={() => window.open('tel:1800-ECO-SWIPE')}
                        className="w-full p-6 flex items-center justify-between hover:bg-gray-50 transition-all"
                      >
                        <div className="flex items-center gap-4">
                          <PhoneCall size={20} className="text-gray-400" />
                          <span className="font-medium">Call Customer Care</span>
                        </div>
                        <ChevronRight size={20} className="text-gray-400" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </main>

        {/* Bottom Nav - Mobile */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 p-4 flex items-center justify-around z-20">
          {[
            { id: 'home', icon: Home },
            { id: role === 'buyer' ? 'buyer' : 'seller', icon: List },
            { id: 'matchmaker', icon: Gamepad2, special: true },
            { id: 'messages', icon: MessageSquare },
            { id: 'profile', icon: User },
          ].filter(item => role === 'buyer' || item.id !== 'matchmaker').map((item) => (
            <button
              key={item.id}
              onClick={() => setScreen(item.id as Screen)}
              className={cn(
                "p-3 rounded-2xl transition-all relative",
                item.special ? cn(bgColor, "text-white -mt-12 shadow-xl scale-110") : 
                screen === item.id ? primaryColor : "text-gray-400"
              )}
            >
              <item.icon size={item.special ? 28 : 24} />
              {(item.id === 'messages') && (notifications.filter(n => !n.read).length > 0 || (role === 'seller' && requests.filter(r => r.status === 'pending').length > 0)) && (
                <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full"></span>
              )}
            </button>
          ))}
        </nav>

        {/* ECO Chatbot */}
        <div className="fixed bottom-24 right-6 z-40">
          <AnimatePresence>
            {isChatOpen && (
              <motion.div
                initial={{ opacity: 0, y: 20, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 20, scale: 0.9 }}
                className="bg-white w-80 h-96 rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-gray-100 mb-4"
              >
                <div className={cn("p-4 text-white flex items-center justify-between", bgColor)}>
                  <div className="flex items-center gap-2">
                    <Leaf size={20} />
                    <span className="font-bold">ECO AI</span>
                  </div>
                  <button onClick={() => setIsChatOpen(false)}><X size={20} /></button>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {chatMessages.length === 0 && (
                    <p className="text-gray-400 text-sm text-center mt-10">Ask me anything about recycling!</p>
                  )}
                  {chatMessages.map((msg, i) => (
                    <div key={i} className={cn("max-w-[80%] p-3 rounded-2xl text-sm", msg.role === 'user' ? "ml-auto bg-gray-100" : cn(bgColor, "text-white"))}>
                      {msg.text}
                    </div>
                  ))}
                  {isChatLoading && (
                    <div className="flex gap-1">
                      <div className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce"></div>
                      <div className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce delay-75"></div>
                      <div className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce delay-150"></div>
                    </div>
                  )}
                </div>
                <div className="p-4 border-t border-gray-100 flex gap-2">
                  <input 
                    type="text" 
                    placeholder="Type a message..." 
                    className="flex-1 bg-gray-50 p-2 rounded-xl text-sm outline-none"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  <button 
                    onClick={handleSendMessage}
                    className={cn("p-2 text-white rounded-xl", bgColor)}
                  >
                    <Send size={18} />
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          <button 
            onClick={() => setIsChatOpen(!isChatOpen)}
            className={cn("w-14 h-14 rounded-full text-white shadow-xl flex items-center justify-center hover:scale-110 transition-all", bgColor)}
          >
            <MessageCircle size={28} />
          </button>
        </div>

        {/* Buy Modal */}
        <AnimatePresence>
          {isBuyModalOpen && selectedListing && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                className="bg-white w-full max-w-md rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden"
              >
                <button 
                  onClick={() => setIsBuyModalOpen(false)}
                  className="absolute top-6 right-6 p-2 bg-gray-100 rounded-full text-gray-500"
                >
                  <X size={20} />
                </button>

                <h2 className="text-2xl font-bold mb-2">Confirm Purchase</h2>
                <p className="text-gray-500 mb-6">{selectedListing.materialType} from {selectedListing.sellerName}</p>

                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-600">How many kgs do you want?</label>
                    <div className="flex items-center gap-4">
                      <input 
                        type="range" 
                        min="1" 
                        max={selectedListing.weight} 
                        step="1"
                        className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-buyer-primary"
                        value={buyWeight}
                        onChange={(e) => setBuyWeight(Number(e.target.value))}
                      />
                      <span className="text-lg font-bold w-16 text-right">{buyWeight} kg</span>
                    </div>
                    <p className="text-xs text-gray-400">Max available: {selectedListing.weight} kg</p>
                  </div>

                  <div className="p-6 bg-gray-50 rounded-3xl space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-500">Market Price</span>
                      <span className="font-bold">₹{MARKET_PRICES[selectedListing.materialType] || MARKET_PRICES['Default']}/kg</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-500">Listing Price</span>
                      <span className="font-bold text-buyer-primary">₹{selectedListing.price}/kg</span>
                    </div>
                    <div className="h-px bg-gray-200"></div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-bold text-gray-800">Potential Profit</span>
                      <span className="text-xl font-black text-green-600">
                        ₹{((MARKET_PRICES[selectedListing.materialType] || MARKET_PRICES['Default']) - selectedListing.price) * buyWeight}
                      </span>
                    </div>
                  </div>

                  <button 
                    onClick={() => sendRequest(selectedListing, buyWeight)}
                    className="w-full py-4 bg-buyer-primary text-white rounded-2xl font-bold shadow-lg hover:scale-[1.02] transition-all"
                  >
                    Send Purchase Request
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Analytics Modal */}
        <AnimatePresence>
          {isAnalyticsOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                className="bg-white w-full max-w-2xl rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden max-h-[90vh] flex flex-col"
              >
                <button 
                  onClick={() => setIsAnalyticsOpen(false)}
                  className="absolute top-6 right-6 p-2 bg-gray-100 rounded-full text-gray-500 z-10"
                >
                  <X size={20} />
                </button>

                <div className="overflow-y-auto flex-1 pr-2 custom-scrollbar">
                  <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                    <BarChart3 className={primaryColor} />
                    {role === 'buyer' ? 'Purchase Analytics' : 'Sustainability Impact'}
                  </h2>

                  <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
                    {(['week', 'month', 'all', 'custom'] as const).map((f) => (
                      <button
                        key={f}
                        onClick={() => setDateFilter(f)}
                        className={cn(
                          "px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap",
                          dateFilter === f ? cn(bgColor, "text-white shadow-md") : "bg-gray-100 text-gray-500 hover:bg-gray-200"
                        )}
                      >
                        {f === 'week' ? 'Last Week' : f === 'month' ? 'Last Month' : f === 'custom' ? 'Custom Range' : 'All Time'}
                      </button>
                    ))}
                  </div>

                  {dateFilter === 'custom' && (
                    <div className="flex gap-4 mb-8 p-4 bg-gray-50 rounded-2xl">
                      <div className="flex-1 space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase">Start Date</label>
                        <input 
                          type="date" 
                          className="w-full bg-transparent outline-none text-sm font-bold"
                          value={customStartDate}
                          onChange={(e) => setCustomStartDate(e.target.value)}
                        />
                      </div>
                      <div className="flex-1 space-y-1">
                        <label className="text-[10px] font-bold text-gray-400 uppercase">End Date</label>
                        <input 
                          type="date" 
                          className="w-full bg-transparent outline-none text-sm font-bold"
                          value={customEndDate}
                          onChange={(e) => setCustomEndDate(e.target.value)}
                        />
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                    <div className="p-4 bg-gray-50 rounded-2xl">
                      <span className="text-xs text-gray-500 block">Total Weight</span>
                      <span className="text-xl font-bold">{analytics.totalWeight.toLocaleString()} kg</span>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-2xl">
                      <span className="text-xs text-gray-500 block">{role === 'buyer' ? 'Total Spent' : 'Total Earned'}</span>
                      <span className="text-xl font-bold">₹{analytics.totalValue.toLocaleString()}</span>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-2xl">
                      <span className="text-xs text-gray-500 block">{role === 'buyer' ? 'Total Profit' : 'Reuse Impact'}</span>
                      <span className={cn("text-xl font-bold", role === 'buyer' ? "text-blue-600" : "text-green-600")}>
                        {role === 'buyer' ? `₹${analytics.profit.toLocaleString()}` : '84%'}
                      </span>
                    </div>
                  </div>

                  <div className="h-64 w-full mb-8">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={analytics.items.length > 0 ? analytics.items.map(r => ({
                        date: new Date(r.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
                        value: (r.price || 0) * (r.weight || 0)
                      })) : [
                        { date: 'Mon', value: 0 },
                        { date: 'Sun', value: 0 },
                      ]}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                        <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#999' }} />
                        <YAxis hide />
                        <Tooltip 
                          contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="value" 
                          stroke={role === 'buyer' ? '#2E7D32' : '#5D4037'} 
                          strokeWidth={4} 
                          dot={{ r: 6, fill: role === 'buyer' ? '#2E7D32' : '#5D4037', strokeWidth: 0 }} 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-bold">Transaction History</h3>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-sm">
                        <thead>
                          <tr className="text-gray-400 border-b border-gray-100">
                            <th className="pb-3 font-medium">Material</th>
                            <th className="pb-3 font-medium">Weight</th>
                            <th className="pb-3 font-medium">Price/kg</th>
                            {role === 'buyer' && <th className="pb-3 font-medium">Market Price</th>}
                            {role === 'buyer' && <th className="pb-3 font-medium text-blue-600">Profit</th>}
                            {role === 'seller' && <th className="pb-3 font-medium text-green-600">Total</th>}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                          {analytics.items.map((item) => {
                            const marketPrice = MARKET_PRICES[item.wasteName] || MARKET_PRICES['Default'];
                            const profit = (marketPrice - (item.price || 0)) * (item.weight || 0);
                            const total = (item.price || 0) * (item.weight || 0);
                            return (
                              <tr key={item.id}>
                                <td className="py-4 font-bold">{item.wasteName}</td>
                                <td className="py-4">{item.weight} kg</td>
                                <td className="py-4">₹{item.price}</td>
                                {role === 'buyer' && <td className="py-4 text-gray-400">₹{marketPrice}</td>}
                                {role === 'buyer' && <td className="py-4 font-bold text-blue-600">₹{profit.toLocaleString()}</td>}
                                {role === 'seller' && <td className="py-4 font-bold text-green-600">₹{total.toLocaleString()}</td>}
                              </tr>
                            );
                          })}
                          {analytics.items.length === 0 && (
                            <tr>
                              <td colSpan={role === 'buyer' ? 5 : 4} className="py-10 text-center text-gray-400 italic">
                                No transactions found for this period
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                <div className="mt-8 flex flex-col sm:flex-row items-center gap-4 pt-4 border-t border-gray-100">
                  <div className="flex-1 flex items-center justify-between p-4 bg-green-50 rounded-2xl border border-green-100 w-full">
                    <div className="flex items-center gap-3">
                      <Leaf className="text-green-600" />
                      <div>
                        <p className="text-sm font-bold text-green-800">Carbon Offset</p>
                        <p className="text-xs text-green-600">You saved 4.2 tons of CO2 this month!</p>
                      </div>
                    </div>
                    <button className="px-4 py-2 bg-green-600 text-white rounded-xl text-xs font-bold">Share Impact</button>
                  </div>
                  <button 
                    onClick={() => {
                      setIsAnalyticsOpen(false);
                      setDateFilter('all');
                      setCustomStartDate('');
                      setCustomEndDate('');
                    }}
                    className="w-full sm:w-auto px-8 py-4 bg-red-500 text-white rounded-2xl font-bold text-sm hover:bg-red-600 transition-all shadow-lg flex items-center justify-center gap-2"
                  >
                    <XCircle size={18} />
                    Exit Analytics
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </ErrorBoundary>
  );
}

// --- Subcomponents ---

function Logo({ className, size = "md" }: { className?: string, size?: "sm" | "md" | "lg" }) {
  const containerSize = size === "sm" ? "h-12" : size === "md" ? "h-20" : "h-32";
  const iconSize = size === "sm" ? 20 : size === "md" ? 32 : 48;
  
  // The user provided a specific logo image. 
  // We assume it's uploaded as /logo.png
  const logoSrc = "/logo.png"; 

  return (
    <div className={cn("flex flex-col items-center justify-center", className)}>
      <div className="relative group">
        <img 
          src={logoSrc} 
          alt="ECO-SWIPE Logo" 
          className={cn("object-contain transition-transform duration-300 group-hover:scale-105", containerSize)}
          onError={(e) => {
            // Fallback UI if image is not found - Recreating the logo feel with icons
            e.currentTarget.style.display = 'none';
            const fallback = e.currentTarget.nextElementSibling as HTMLElement;
            if (fallback) fallback.style.display = 'flex';
          }}
        />
        
        {/* Fallback Logo (Icon-based recreation) */}
        <div className="hidden flex-col items-center justify-center gap-1">
          <div className="relative">
            <div className="w-16 h-16 bg-blue-50 dark:bg-blue-900/30 rounded-full flex items-center justify-center border-2 border-blue-100 dark:border-blue-800 shadow-inner">
              <Globe size={iconSize * 1.2} className="text-blue-400 opacity-40" />
            </div>
            <div className="absolute -top-2 left-1/2 -translate-x-1/2">
              <Truck size={iconSize * 0.8} className="text-green-600 fill-green-50 dark:fill-green-900/50" />
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <RefreshCw size={iconSize * 0.6} className="text-green-500 animate-spin-slow" />
            </div>
          </div>
          <h1 className="font-black tracking-tighter uppercase text-xl">
            <span className="text-green-600">Eco</span>
            <span className="text-gray-800 dark:text-gray-200">-Swipe</span>
          </h1>
        </div>
      </div>
    </div>
  );
}

function ListingCard({ listing, onAction, onDelete, isBuyer, isSellerOwn }: { listing: Listing, onAction: () => void, onDelete?: () => void, isBuyer?: boolean, isSellerOwn?: boolean }) {
  const [showDetails, setShowDetails] = useState(false);
  const [requested, setRequested] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleRequest = () => {
    onAction();
    setRequested(true);
  };

  return (
    <div className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-md transition-all border border-gray-50 group relative">
      <div className="relative h-48">
        <img src={listing.imageUrl} className="w-full h-full object-cover" alt={listing.materialType} />
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold shadow-sm">
          {listing.quality}
        </div>
        {isBuyer && (
          <div className="absolute top-4 left-4 bg-yellow-400 text-black px-3 py-1 rounded-full text-xs font-bold shadow-sm flex items-center gap-1">
            <ShieldCheck size={12} /> Best Match
          </div>
        )}
        {isSellerOwn && (
          <div className="absolute top-4 left-4 bg-seller-primary text-white px-3 py-1 rounded-full text-xs font-bold shadow-sm">
            My Listing
          </div>
        )}
        {isSellerOwn && (
          <button 
            onClick={() => setIsDeleting(true)}
            className="absolute bottom-4 right-4 p-2 bg-red-500 text-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <Trash2 size={16} />
          </button>
        )}
      </div>
      <div className="p-6 space-y-4">
        <div className="flex justify-between items-start">
          <div>
            <h4 className="text-xl font-bold dark:text-white">{listing.materialType}</h4>
            <div className="flex items-center gap-2 mt-1">
              <p className="text-sm text-gray-500 flex items-center gap-1">
                <MapPin size={14} /> {listing.location}
              </p>
              <span className="text-[10px] bg-green-50 text-green-600 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                <ShieldCheck size={10} /> {listing.sellerTrustScore}% Trust
              </span>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-black text-buyer-primary">₹{listing.price}/kg</p>
            <p className="text-xs text-gray-400">{listing.weight}kg available</p>
          </div>
        </div>

        <div className="flex gap-2">
          <button 
            onClick={() => setShowDetails(!showDetails)}
            className="flex-1 py-3 bg-gray-50 rounded-xl font-bold text-gray-600 text-sm"
          >
            Details
          </button>
          {isBuyer && (
            <button 
              onClick={handleRequest}
              disabled={requested}
              className={cn(
                "flex-1 py-3 rounded-xl font-bold text-sm transition-all",
                requested ? "bg-white border-2 border-black text-black" : "bg-buyer-primary text-white"
              )}
            >
              {requested ? 'Requested' : 'Request'}
            </button>
          )}
        </div>

        {isDeleting && (
          <div className="absolute inset-0 bg-white/95 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-20">
            <Trash2 size={40} className="text-red-500 mb-4" />
            <h4 className="text-lg font-bold mb-2">Delete Listing?</h4>
            <p className="text-sm text-gray-500 mb-6">This action cannot be undone and will remove it from the database.</p>
            <div className="flex gap-3 w-full">
              <button 
                onClick={() => setIsDeleting(false)}
                className="flex-1 py-3 bg-gray-100 rounded-xl font-bold text-gray-600"
              >
                Cancel
              </button>
              <button 
                onClick={() => {
                  onDelete?.();
                  setIsDeleting(false);
                }}
                className="flex-1 py-3 bg-red-500 text-white rounded-xl font-bold"
              >
                Delete
              </button>
            </div>
          </div>
        )}

        {showDetails && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            className="pt-4 border-t border-gray-50 space-y-3"
          >
            <p className="text-sm text-gray-600 font-medium">AI Recommendations:</p>
            <div className="flex flex-wrap gap-2">
              {listing.suggestedIndustries.map((ind, i) => (
                <span key={i} className="px-3 py-1 bg-gray-100 rounded-lg text-xs font-medium text-gray-500">{ind}</span>
              ))}
            </div>
            <button 
              onClick={() => window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(listing.location)}`)}
              className="w-full py-2 flex items-center justify-center gap-2 text-sm font-bold text-buyer-primary"
            >
              <MapPin size={16} /> View on Maps
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
