import { GoogleGenAI, Type } from "@google/genai";
import { AIResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function classifyWaste(base64Image: string): Promise<AIResult> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      {
        parts: [
          {
            inlineData: {
              data: base64Image.split(",")[1],
              mimeType: "image/jpeg",
            },
          },
          {
            text: "Classify this industrial waste. Provide the material type, estimated price per kg in INR, quality (e.g., Grade A, Recyclable), and a list of 3 suggested industries that can use this waste. Respond in JSON format.",
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          materialType: { type: Type.STRING },
          suggestedPrice: { type: Type.NUMBER },
          quality: { type: Type.STRING },
          suggestedIndustries: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
        },
        required: ["materialType", "suggestedPrice", "quality", "suggestedIndustries"],
      },
    },
  });

  return JSON.parse(response.text || "{}") as AIResult;
}

export async function getRecyclingAdvice(material: string, history: { role: 'user' | 'model', text: string }[]): Promise<string> {
  const chat = ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: "You are ECO, an AI recycling expert. Recommend recycling methods for specific waste categories. Provide the best method (lowest emission), alternative options, and a total recycling method overview. Always prioritize the most eco-friendly and lowest emission options.",
    },
  });

  const response = await chat.sendMessage({
    message: `What are the best recycling methods for ${material}?`,
  });

  return response.text || "I'm sorry, I couldn't find any recycling advice for that material.";
}
