export type Role = 'buyer' | 'seller';
export type Screen = 'home' | 'buyer' | 'seller' | 'matchmaker' | 'messages' | 'profile';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: Role;
  trustScore: number;
  earnings: number;
  totalWeight?: number;
  totalProfit?: number;
  darkMode: boolean;
}

export interface Listing {
  id: string;
  sellerId: string;
  sellerName: string;
  materialType: string;
  weight: number;
  price: number;
  location: string;
  quality: string;
  suggestedIndustries: string[];
  imageUrl: string;
  sellerTrustScore: number;
  createdAt: string;
}

export interface Request {
  id: string;
  listingId: string;
  buyerId: string;
  buyerName: string;
  sellerId: string;
  status: 'pending' | 'accepted' | 'rejected';
  wasteName: string;
  price?: number;
  weight?: number;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  message: string;
  type: string;
  read: boolean;
  createdAt: string;
}

export interface AIResult {
  materialType: string;
  suggestedPrice: number;
  quality: string;
  suggestedIndustries: string[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface AnalyticsData {
  totalWeight: number;
  totalEarnings: number;
  reusePercentage: number;
  history: { date: string; value: number }[];
}
